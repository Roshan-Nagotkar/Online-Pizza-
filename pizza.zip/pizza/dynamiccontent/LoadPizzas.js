(function ($) {

    $(function () { // ON DOM READY


        var data1 = pizza,
            target = $('#target'),
            html;

        $.each(data1, function (key, val) {
            //<img src ="' + val.image_url + '" class="image-styles" /><p class="image-title">' + val.title + '</p>

            if ((key % 2) == 0) {
                html = '<div class="fh5co-v-half">';
                html += '<div class="fh5co-h-row-2 to-animate-2" id="maindiv' + key + '" >';
                html += '<div class="fh5co-v-col-2 fh5co-bg-img" style="background-image: url(' + val.image_url + ')"></div> ';
                html += '<div class="fh5co-v-col-2 fh5co-text arrow-left">';
                html += '<h2>' + val.title + '</h2>';
                html += '<span class="pricing"><i class="icon-inr"></i>  ' + val.amount + '</span>';
                html += '<p>' + val.ingredient + '</p> ';
                if (val.discount != "") {
                    html += '<p style="font-weight:bold; font-size:18px">Discount ' + val.discount + '%</p> ';
                }
                html += '<input type="button" class="btn btn-success" id="btnclick" onclick="Showdiv(div' + key + ',maindiv' + key + ')" value="Quick Add" />';

                html += '<div class="content" id="div' + key + '" style="display:none" class="">Product added to cart</div>';
                html += '</div></div>';
                // target.append(html);
            }
            else {

                html += '<div class="fh5co-h-row-2 fh5co-reversed to-animate-2" id="maindiv' + key + '" >';
                html += '<div class="fh5co-v-col-2 fh5co-bg-img" style="background-image: url(' + val.image_url + ')"></div> ';
                html += '<div class="fh5co-v-col-2 fh5co-text arrow-right">';
                html += '<h2>' + val.title + '</h2>';
                html += '<span class="pricing"><i class="icon-inr"></i>  ' + val.amount + '</span>';
                html += '<p>' + val.ingredient + '</p> ';
                if (val.discount != "") {
                    html += '<p style="font-weight:bold; font-size:18px">Discount ' + val.discount + '%</p> ';
                }
                html += '<input type="button" class="btn btn-success" id="btnclick" onclick="Showdiv(div' + key + ',maindiv' + key + ')" value="Quick Add" />';
                html += '<div class="content" id="div' + key + '" style="display:none" class="">Product added to cart</div>';
                html += '</div></div></div>';
                target.append(html);

            }
        });



    }); // end of on DOM READY

}(jQuery));